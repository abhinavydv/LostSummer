# Lost Summer
The demon king has stolen the sun, summer is no more their property and all have to live in dark.
A small teenage ninja boy has pledged to defeat the demon king and bring summer back.

## Controls
- Left and Right Arrow keys ->  Move
- Spacebar -> Jump
- Enter -> File Kunai
- Q -> Use sword

## Requirements
Run the following command to install all python libraries needed for running the project  
`pip install -r requirements.txt`
